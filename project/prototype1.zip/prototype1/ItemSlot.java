import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Shows what item(s) the play is currently holding
 * 
 * @author Cole Tomaro
 * @version 11/19/18
 */
public class ItemSlot extends HUD
{
   
    public void act() 
    {
    }
    
    public void addItem()
    {
    }
    
    public void removeItem()
    {
    }
    
}
