import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Mainly a group for all the HUD elements.
 * This class a few methods to show/hide said elements.
 * 
 * @author Cole Tomaro
 * @version 11/19/18
 */
public class HUD extends Actor
{
    public void act() 
    {
        // Add your action code here.
    }
    
    public void showHud()
    {
    }
    
    public void hideHud()
    {
    }
    
    public void hideHealth()
    {
    }
    
    public void showHealth()
    {
    }
    
    public void hideItems()
    {
    }
    
    public void showItems()
    {
    }
}
