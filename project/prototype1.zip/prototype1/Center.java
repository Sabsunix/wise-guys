import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * 2d center surface grass tile image. IMAGE = Center.png
 * 
 * @author Nicholas Anderson 
 * @version V1.0 November 15, 2018
 */
public class Center extends Platform
{
    /**
     * Image Placeholder Class
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
