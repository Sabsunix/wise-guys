import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The enemy that will have the ability to bounce around
 * 
 * @author William Craig 
 * @version 11/20/18
 */
public class Enemy_bouncing extends Sprite
{
    /**
     * Act - do whatever the Enemy_bouncing wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
