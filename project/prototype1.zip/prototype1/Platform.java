import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * 2d surface platform character moves on. IMAGE=Untitled.png
 * 
 * @author Nicholas Anderson 
 * @version V1.0
 * @date November 15, 2018
 */
public class Platform extends Actor
{
    /**
     * Act - image place holder class
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
