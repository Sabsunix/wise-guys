import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Image of a door for level map. will also open and close
 * IMAGE = door.png
 *
 * @author Nicholas Anderson
 * @version 1.0, November 18, 2018
 */
public class Door extends Platform
{
    /**
     * animation of door opening closing?
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
