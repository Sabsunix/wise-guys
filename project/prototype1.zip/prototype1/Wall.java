import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Image of castle walls, building walls. IMAGE = wall.png
 * 
 * @author Nicholas Anderson 
 * @version 1.0, November 18, 2018
 */
public class Wall extends Platform
{
    /**
     * Act - do whatever the Wall wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
