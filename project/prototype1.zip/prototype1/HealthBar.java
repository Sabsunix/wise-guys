import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Displays the player's health
 * 
 * @author Cole Tomaro
 * @version 11/19/18
 */
public class HealthBar extends HUD
{
    public void act() 
    {
    }
    
    public void addHealth(int amount)
    {
    }
    
    public void subtractHealth(int amount)
    {
    }
}
