import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * 2d right facing surface edge grass tile image. IMAGE = right.png
 * 
 * @author Nicholas Anderson 
 * @version V1.0 November 15, 2018
 */
public class Right extends Platform
{
    /**
     * Image Placeholder Class
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
